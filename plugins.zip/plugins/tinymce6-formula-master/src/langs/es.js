tinymce.addI18n('es', {
  'Formula': 'Editor de ecuaciones',
  'Cancel': 'Cancelar',
  'Insert Formula': 'Insertar ecuacione'
})
