tinymce.addI18n('fr_FR', {
  'Formula': 'Éditeur d\'équations',
  'Cancel': 'Annuler',
  'Insert Formula': 'Insérer l\'équation'
})
