tinymce.addI18n('ar', {
  'Formula': 'المعادلات رياضية',
  'Cancel': 'إلغاء',
  'Insert Formula': 'أنشئ المعادلة'
})
