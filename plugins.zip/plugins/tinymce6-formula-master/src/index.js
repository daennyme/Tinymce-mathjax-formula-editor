// Exports the "tinymce6-formula" plugin for usage with module loaders
// Usage:
//   CommonJS:
//     require('tinymce/plugins/tinymce6-formula')
//   ES2015:
//     import 'tinymce/plugins/tinymce6-formula'
require('./plugin.js');